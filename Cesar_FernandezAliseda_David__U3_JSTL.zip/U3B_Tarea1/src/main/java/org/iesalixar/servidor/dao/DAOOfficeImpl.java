package org.iesalixar.servidor.dao;

import java.util.List;
import org.iesalixar.servidor.models.Office;

public class DAOOfficeImpl implements DAOOffice{

	@Override
	public List<Office> getAllOffices() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean updateOffice(Office office) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean insertOffice(Office office) {
		// TODO Auto-generated method stub
		return false;
	}

}
